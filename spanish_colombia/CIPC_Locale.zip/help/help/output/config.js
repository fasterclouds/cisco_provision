//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Utilizaci�n de la ayuda";

//Application title. This will be the title of index.html
var appTitle = "Ayuda en l�nea de Cisco IP Communicator";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Atr�s";

//Label for close function
var close = "";

//label for contents tab
var contents = "Contenido";

//label for contents collpase 
var collapse = "Contraer todo";

//label for V4 search button
var doSearch = "Ir";

//label for contents expand
var expand = "Expandir todo";

//label for favorites
var favorites = "Favoritos";

//label for favorites add button
var favAdd = "Agregar";

//label for favorites enter field
var favEnter = "Tema actual:";

//label for favorites remove button
var favRemove = "Quitar";

//label for feedback
var feedback = "Comentarios";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Adelante";

//label for glossay
var glossary = "Glosario";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Ocultar";

//label for "go to top toc"
var home = "Inicio";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "�ndice";

//label for index enter field
var indexEnter = "Escribir la palabra clave para buscar:";

//label for index popup when no URL
var indexPopup = "Para encontrar informaci�n acerca de esta palabra clave, seleccione una de las subentradas de la lista.";

//label for pdf
var pdf = "Ver PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Imprimir";

//label for search
var search = "Buscar";

//search group, should be the same appears in mappingfile
var searchGroup = "Todos";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Opcional";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Mostrar";

//default start page
var startPage = "ipcuggs1.html";
