if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Ayuda en l�nea de Cisco IP Communicator
// 
//Copyright � 2009 Cisco Systems, Inc. Reservados todos los derechos.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Configuraci�n de usuario 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp247153";

// Configuraci�n de red 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp247184";

// Configuraci�n de audio 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp247213";

// Configuraci�n de audio de red 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp247467";

// Configuraci�n de audio avanzada 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp247502";

// Configuraci�n de directorios 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp247529";

// Utilizaci�n de la funci�n de b�squeda r�pida 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp465541";

